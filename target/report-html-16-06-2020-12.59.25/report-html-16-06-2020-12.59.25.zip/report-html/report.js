$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("file:src/test/resources/features/Google.feature");
formatter.feature({
  "name": "Pesquisa no google",
  "description": "",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@Google"
    }
  ]
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "que acesso o site do google",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.acessoOpen()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Acesso site GloboEsporte",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@Google"
    },
    {
      "name": "@Run"
    }
  ]
});
formatter.step({
  "name": "pesquiso pelo site \"https://www.globo.com/\"",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.pesquisoSiteLancenet(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "acesso o primeiro site retornado do globo",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefinition.acessoPrimeiroSiteRetornadoGlobo()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "clico no link para o GloboEsporte",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefinition.clicoLinkGloboEsporte()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "valido o logo do site Globo Esporte",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.validoConteudoTituloGloboEsporte()"
});
formatter.result({
  "error_message": "org.junit.ComparisonFailure: expected:\u003c[TesteAlteracao ]globoesporte.com\u003e but was:\u003c[]globoesporte.com\u003e\r\n\tat org.junit.Assert.assertEquals(Assert.java:117)\r\n\tat org.junit.Assert.assertEquals(Assert.java:146)\r\n\tat br.com.squadra.test.core.DSL.validarConteudo(DSL.java:181)\r\n\tat br.com.squadra.test.pages.GloboesportePage.validarConteudoTitulo(GloboesportePage.java:13)\r\n\tat br.com.squadra.test.steps.StepDefinition.validoConteudoTituloGloboEsporte(StepDefinition.java:73)\r\n\tat ✽.valido o logo do site Globo Esporte(file:src/test/resources/features/Google.feature:14)\r\n",
  "status": "failed"
});
formatter.after({
  "status": "passed"
});
});